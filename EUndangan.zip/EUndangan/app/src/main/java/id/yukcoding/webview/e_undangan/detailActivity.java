package id.yukcoding.webview.e_undangan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

public class detailActivity extends AppCompatActivity {
TextView hal2,hal22;
String tekshal2="<p><h3>Desta & Adit\n" +
        "\n" +
        "Ya Allah, Kumpulkan mereka dalam kebaikan dan satukan hati mereka berdua\n" +
        "dan berikan pada mereka keturunan yang menjadi penduduk syurga.\n" +
        "Serta berikan atas mereka berdua seorang keturunan yang bagus dan suci,\n" +
        "yang penuh keberkahan. Dan jadikan setiap anak cucu mereka keberkahan dan\n" +
        "jadikan mereka semua para pemimpin yang memberi \n" +
        "hidayah dengan perintah-perintah-Mu kepada ketaatan</h3></p>";
String tekshal22="<p><h2>Denah Lokasi \n" +
        "Jln. Purnawirawan Gg.Swadaya 2, Kel.Gunung Terang Kec. Langkapura - Bandar Lampung</h2></p>";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

       hal2 = (TextView)findViewById(R.id.textView8);
        hal2.setText(Html.fromHtml(tekshal2));

        hal22 = (TextView)findViewById(R.id.textView8);
        hal22.setText(Html.fromHtml(tekshal22));
    }
    public void mapping(View view) {
        Uri peta = Uri.parse("google.navigation:q=Jln+Purnawirawan+Gg+Swadaya+2+Gunung+Terang+Langkapura+Bandar+Lampung");
        Intent intentPeta = new Intent(Intent.ACTION_VIEW, peta);
        intentPeta.setPackage("com.google.android.apps.maps");
        startActivity(intentPeta);

    }
}
