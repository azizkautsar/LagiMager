package id.yukcoding.webview.e_undangan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView teks1,teks2,teks3,teks4,teks5,teks6,teks7,teks8,teks9,teks10,teks11,teks12;
    String tekshtml1="<p><h2>Bismillahirahmanirrahim\n" +
            "Assalamualaikum Warahmatullahi Wabarakatuh\n" +
            "Dengan Do'a dan Kasih Sayang, Kami besarkan putra dan putri kami " +
            "Kini Engkau satukan hati mereka dalam bahtera rumah tangga " +
            "Ya Allah, Ridhai dan tuntun mereka putra dan putri kami :</h2></p>";
    String tekshtml2="<p><h1>Desta Triringki Liasari S.Pd</h1>\n" +
            "<h3>Anak Kedua dari Bpk.Hi. Parmono & Ibu Hj.Akmaliah, S.Pd</h3>\n" +
            "Dengan \n" +
            "<h1>Adittyo Yunanta</h1>\n" +
            "<h3>Anak kedua dari Bpk. Sutisna & Ibu Dra.Yulianela</h3></p>";

    String tekshtml3="<p><h4>Yang Insya Allah akan diselenggarakan pada :</h4></p>";

    String tekshtml4="<p><h3>AKAD NIKAH :\n" +
            "SABTU\n" +
            "PUKUL :\n" +
            "07.00 WIB s/d selesai</h3></p>";
    String tekshtml5="<p><h2>5 Januari 2019</h2></p>";
    String tekshtml6="<p><h3>RESEPSI :\n" +
            "SABTU\n" +
            "PUKUL :\n" +
            "10.00 WIB s/d selesai</h3></p>";
    String tekshtml7="<p><h2>Jln. Purnawirawan Gg.Swadaya 2, Kel.Gunung Terang Kec. Langkapura - Bandar Lampung</h2></p>";
    String tekshtml8="<p><h3>Kehadiran adalah silahturahmi, restu adalah cinta kasih dan keikhlasan adalah ketulusan " +
            "maka tiada yang lebuh bahagia bagi kami sekeluarga selain langkah yang ringan, " +
            "do'a restu tulus dalam kehadiran Bapak/Ibu/Saudara/i, bagi putra-putri kami.</h3></p>";
    String tekshtml9="<p><h2>Wassalamualaikum Warahmatullahi Wabarakatuh</h2></p>";
    String tekshtml10="<p><h2>Keluarga Besar \n" +
            "Bpk.Hi. Parmono & Ibu Hj.Akmaliah, S.Pd</h2></p>";
    String tekshtml11="<p><h2>Keluarga Besar \n" +
            "Bpk. Sutisna & Ibu Dra.Yulianela</h2></p>";
    String tekshtml12="<p><h1>Desta & Adit</h1></p>";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setContentView(R.layout.activity_main);

        teks1 = (TextView)findViewById(R.id.textView);
        teks1.setText(Html.fromHtml(tekshtml1));

        teks2 = (TextView)findViewById(R.id.textView2);
        teks2.setText(Html.fromHtml(tekshtml2));

        teks3 = (TextView)findViewById(R.id.textView3);
        teks3.setText(Html.fromHtml(tekshtml3));

        teks4 = (TextView)findViewById(R.id.textView4);
        teks4.setText(Html.fromHtml(tekshtml4));

        teks5 = (TextView)findViewById(R.id.textView5);
        teks5.setText(Html.fromHtml(tekshtml5));

        teks6 = (TextView)findViewById(R.id.textView6);
        teks6.setText(Html.fromHtml(tekshtml6));

        teks7 = (TextView)findViewById(R.id.textView7);
        teks7.setText(Html.fromHtml(tekshtml7));

        teks8 = (TextView)findViewById(R.id.textView8);
        teks8.setText(Html.fromHtml(tekshtml8));

        teks9 = (TextView)findViewById(R.id.textView9);
        teks9.setText(Html.fromHtml(tekshtml9));

        teks10 = (TextView)findViewById(R.id.textView10);
        teks10.setText(Html.fromHtml(tekshtml10));

        teks11 = (TextView)findViewById(R.id.textView11);
        teks11.setText(Html.fromHtml(tekshtml11));

        teks12 = (TextView)findViewById(R.id.textView12);
        teks12.setText(Html.fromHtml(tekshtml12));
    }


    public void pindah(View view) {
        Intent pindah = new Intent(this, detailActivity.class);
        startActivity(pindah);
    }
}
